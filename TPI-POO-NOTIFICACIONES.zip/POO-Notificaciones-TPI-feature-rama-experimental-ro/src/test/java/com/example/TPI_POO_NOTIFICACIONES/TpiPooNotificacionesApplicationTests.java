package com.example.TPI_POO_NOTIFICACIONES;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpiPooNotificacionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
