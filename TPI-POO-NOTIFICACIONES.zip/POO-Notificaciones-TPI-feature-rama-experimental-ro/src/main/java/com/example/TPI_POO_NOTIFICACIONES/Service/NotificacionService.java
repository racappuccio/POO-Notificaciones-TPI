package com.example.TPI_POO_NOTIFICACIONES.Service;

import com.example.TPI_POO_NOTIFICACIONES.Entity.EstadoNotificacion;
import com.example.TPI_POO_NOTIFICACIONES.Entity.Notificacion;
import com.example.TPI_POO_NOTIFICACIONES.Entity.Plantilla;
import com.example.TPI_POO_NOTIFICACIONES.Exceptions.BadRequestException;
import com.example.TPI_POO_NOTIFICACIONES.Exceptions.ResourceNotFoundException;
import com.example.TPI_POO_NOTIFICACIONES.Repository.NotificacionRepository;
import com.example.TPI_POO_NOTIFICACIONES.Repository.PlantillaRepository;
import com.example.TPI_POO_NOTIFICACIONES.Request.NotificacionRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
public class NotificacionService {

    private final NotificacionRepository notificacionRepository;
    private final PlantillaRepository plantillaRepository;

    public NotificacionService(NotificacionRepository notificacionRepository,
                               PlantillaRepository plantillaRepository) {
        this.notificacionRepository = notificacionRepository;
        this.plantillaRepository = plantillaRepository;
    }

    @Transactional
    public Notificacion crearNotificacion(NotificacionRequest request) {
        Plantilla plantilla = plantillaRepository.findById(request.getPlantillaId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Plantilla con id " + request.getPlantillaId() + " no encontrada"));

        // ✅ Validar que las variables obligatorias estén presentes
        Map<String, String> vars = request.getVars();
        if (vars == null
                || !vars.containsKey("nombre") || vars.get("nombre") == null || vars.get("nombre").isBlank()
                || !vars.containsKey("fecha") || vars.get("fecha") == null || vars.get("fecha").isBlank()) {
            throw new BadRequestException("Las variables 'nombre' y 'fecha' son obligatorias para crear una notificación");
        }

        // Renderizar cuerpo reemplazando variables
        String cuerpoFinal = plantilla.getCuerpo();
        for (var entry : vars.entrySet()) {
            cuerpoFinal = cuerpoFinal.replace("{{" + entry.getKey() + "}}", entry.getValue());
        }

        // Canal heredado directamente de la plantilla
        Notificacion notificacion = new Notificacion(
                request.getUserId(),
                request.getDestinatario(),
                plantilla.getCanal(),
                plantilla
        );
        notificacion.setCuerpoFinal(cuerpoFinal);

        return notificacionRepository.save(notificacion);
    }

    public List<Notificacion> obtenerTodas() {
        return notificacionRepository.findAll();
    }

    public List<Notificacion> obtenerPorUsuario(Long userId) {
        return notificacionRepository.findByUserId(userId);
    }

    @Transactional
    public boolean eliminar(Long id) {
        if (!notificacionRepository.existsById(id)) {
            throw new ResourceNotFoundException("Notificación con id " + id + " no encontrada");
        }
        notificacionRepository.deleteById(id);
        return true;
    }

    @Transactional
    public Notificacion actualizarParcial(Long id, String nuevoEstado) {
        Notificacion notificacion = notificacionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Notificación con id " + id + " no encontrada"));

        try {
            notificacion.setEstado(EstadoNotificacion.valueOf(nuevoEstado));
        } catch (IllegalArgumentException e) {
            throw new BadRequestException("Estado inválido: " + nuevoEstado);
        }

        return notificacionRepository.save(notificacion);
    }
}