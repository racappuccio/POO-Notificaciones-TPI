package com.example.TPI_POO_NOTIFICACIONES.Controller;

import com.example.TPI_POO_NOTIFICACIONES.Entity.Notificacion;
import com.example.TPI_POO_NOTIFICACIONES.Service.NotificacionService;
import com.example.TPI_POO_NOTIFICACIONES.Request.NotificacionRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/notificacion")
public class NotificacionController {

    private final NotificacionService notificacionService;

    public NotificacionController(NotificacionService notificacionService) {
        this.notificacionService = notificacionService;
    }

    // Crear notificación
    @PostMapping
    public ResponseEntity<Notificacion> crear(@RequestBody NotificacionRequest request) {
        Notificacion notificacion = notificacionService.crearNotificacion(request);
        return ResponseEntity.ok(notificacion);
    }

    // Obtener todas las notificaciones
    @GetMapping
    public List<Notificacion> obtenerTodas() {
        return notificacionService.obtenerTodas();
    }

    // Obtener notificaciones por usuario
    @GetMapping("/usuario/{userId}")
    public List<Notificacion> obtenerPorUsuario(@PathVariable Long userId) {
        return notificacionService.obtenerPorUsuario(userId);
    }

    // Eliminar notificación
    @DeleteMapping("/id/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        notificacionService.eliminar(id);
        return ResponseEntity.noContent().build();
    }

    // Actualizar estado de notificación (PATCH)
    @PatchMapping("/id/{id}")
    public ResponseEntity<Notificacion> actualizarEstado(
            @PathVariable Long id,
            @RequestBody String nuevoEstado) {
        Notificacion actualizada = notificacionService.actualizarParcial(id, nuevoEstado);
        return ResponseEntity.ok(actualizada);
    }
}