package com.example.TPI_POO_NOTIFICACIONES.Controller;

import com.example.TPI_POO_NOTIFICACIONES.Entity.Plantilla;
import com.example.TPI_POO_NOTIFICACIONES.Service.PlantillaService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/plantillas")
public class PlantillaController {

    private final PlantillaService plantillaService;

    public PlantillaController(PlantillaService plantillaService) {
        this.plantillaService = plantillaService;
    }

    @GetMapping
    public List<Plantilla> obtenerTodas() {
        return plantillaService.obtenerTodas();
    }

    @PostMapping
    public ResponseEntity<Plantilla> crear(@RequestBody Plantilla plantilla) {
        return ResponseEntity.ok(plantillaService.crear(plantilla));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        plantillaService.eliminar(id);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/id/{id}")
    public ResponseEntity<Plantilla> actualizarParcial(
            @PathVariable Long id,
            @RequestBody Map<String, Object> updates) {
        return ResponseEntity.ok(plantillaService.actualizarParcial(id, updates));
    }
}