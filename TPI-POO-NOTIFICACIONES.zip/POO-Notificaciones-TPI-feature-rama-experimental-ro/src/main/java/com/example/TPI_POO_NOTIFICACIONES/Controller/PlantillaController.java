package com.example.TPI_POO_NOTIFICACIONES.Controller;

import com.example.TPI_POO_NOTIFICACIONES.Entity.Plantilla;
import com.example.TPI_POO_NOTIFICACIONES.Request.PlantillaRequest;
import com.example.TPI_POO_NOTIFICACIONES.Response.PlantillaResponse;
import com.example.TPI_POO_NOTIFICACIONES.Service.PlantillaService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/plantillas")
public class PlantillaController {

    private final PlantillaService plantillaService;

    public PlantillaController(PlantillaService plantillaService) {
        this.plantillaService = plantillaService;
    }

    @PostMapping
    public ResponseEntity<PlantillaResponse> crear(@RequestBody PlantillaRequest request) {
        Plantilla plantilla = plantillaService.crearPlantilla(request);
        return ResponseEntity.ok(new PlantillaResponse(plantilla));
    }

    @GetMapping
    public ResponseEntity<List<PlantillaResponse>> obtenerTodas() {
        List<Plantilla> plantillas = plantillaService.obtenerTodas();
        List<PlantillaResponse> response = plantillas.stream()
                .map(PlantillaResponse::new)
                .collect(Collectors.toList());
        return ResponseEntity.ok(response);
    }

    @GetMapping("/{id}")
    public ResponseEntity<PlantillaResponse> obtenerPorId(@PathVariable Long id) {
        Plantilla plantilla = plantillaService.obtenerPorId(id);
        return ResponseEntity.ok(new PlantillaResponse(plantilla));
    }

    @PatchMapping("/{id}")
    public ResponseEntity<PlantillaResponse> actualizarParcial(
            @PathVariable Long id,
            @RequestBody PlantillaRequest request) {
        Plantilla plantilla = plantillaService.actualizarParcial(id, request);
        return ResponseEntity.ok(new PlantillaResponse(plantilla));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        plantillaService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}