package com.example.TPI_POO_NOTIFICACIONES.Service;

import com.example.TPI_POO_NOTIFICACIONES.Entity.Canal;
import com.example.TPI_POO_NOTIFICACIONES.Entity.Plantilla;
import com.example.TPI_POO_NOTIFICACIONES.Exceptions.BadRequestException;
import com.example.TPI_POO_NOTIFICACIONES.Exceptions.ResourceNotFoundException;
import com.example.TPI_POO_NOTIFICACIONES.Repository.NotificacionRepository;
import com.example.TPI_POO_NOTIFICACIONES.Repository.PlantillaRepository;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
public class PlantillaService {

    private final PlantillaRepository plantillaRepository;
    private final NotificacionRepository notificacionRepository;

    public PlantillaService(PlantillaRepository plantillaRepository,
                            NotificacionRepository notificacionRepository) {
        this.plantillaRepository = plantillaRepository;
        this.notificacionRepository = notificacionRepository;
    }

    public List<Plantilla> obtenerTodas() {
        return plantillaRepository.findAll();
    }

    @Transactional
    public Plantilla crear(Plantilla plantilla) {
        return plantillaRepository.save(plantilla);
    }

    @Transactional
    public boolean eliminar(Long id) {
        Plantilla plantilla = plantillaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Plantilla con id " + id + " no encontrada"));

        // ✅ Usar el método correcto con el ID
        if (notificacionRepository.existsByPlantilla_Id(id)) {
            throw new BadRequestException("Esta plantilla está en uso y no puede eliminarse");
        }

        try {
            plantillaRepository.deleteById(id);
            return true;
        } catch (DataIntegrityViolationException e) {
            // fallback por si la BD lanza el error de constraint
            throw new BadRequestException("Esta plantilla está en uso y no puede eliminarse");
        }
    }

    @Transactional
    public Plantilla actualizarParcial(Long id, Map<String, Object> updates) {
        Plantilla plantilla = plantillaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Plantilla con id " + id + " no encontrada"));

        if (updates.containsKey("asunto")) {
            plantilla.setAsunto((String) updates.get("asunto"));
        }
        if (updates.containsKey("cuerpo")) {
            plantilla.setCuerpo((String) updates.get("cuerpo"));
        }
        if (updates.containsKey("canal")) {
            plantilla.setCanal(Canal.valueOf((String) updates.get("canal")));
        }

        return plantillaRepository.save(plantilla);
    }
}