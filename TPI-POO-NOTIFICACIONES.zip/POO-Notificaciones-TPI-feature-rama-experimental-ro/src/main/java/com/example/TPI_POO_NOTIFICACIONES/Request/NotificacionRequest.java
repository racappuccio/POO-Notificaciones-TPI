package com.example.TPI_POO_NOTIFICACIONES.Request;

import java.util.Map;

public class NotificacionRequest {
    private Long userId;              // ID del usuario destinatario
    private String destinatario;      // dirección de correo o identificador interno
    private Long plantillaId;         // ID de la plantilla a usar
    private Map<String, String> vars; // variables dinámicas para renderizar el cuerpo

    // Getters y setters
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getDestinatario() { return destinatario; }
    public void setDestinatario(String destinatario) { this.destinatario = destinatario; }

    public Long getPlantillaId() { return plantillaId; }
    public void setPlantillaId(Long plantillaId) { this.plantillaId = plantillaId; }

    public Map<String, String> getVars() { return vars; }
    public void setVars(Map<String, String> vars) { this.vars = vars; }
}