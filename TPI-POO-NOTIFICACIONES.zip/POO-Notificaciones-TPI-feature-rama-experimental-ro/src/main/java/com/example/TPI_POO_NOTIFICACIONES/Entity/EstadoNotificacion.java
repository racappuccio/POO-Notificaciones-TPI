package com.example.TPI_POO_NOTIFICACIONES.Entity;

public enum EstadoNotificacion {
    EN_COLA, ENVIADA, ERROR
}