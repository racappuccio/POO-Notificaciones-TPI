package com.example.TPI_POO_NOTIFICACIONES.Response;

import com.example.TPI_POO_NOTIFICACIONES.Entity.Canal;
import com.example.TPI_POO_NOTIFICACIONES.Entity.EstadoNotificacion;
import com.example.TPI_POO_NOTIFICACIONES.Entity.Notificacion;

public class NotificacionResponse {
    private Long id;
    private Long userId;
    private String destinatario;
    private Canal canal;
    private String cuerpoFinal;
    private EstadoNotificacion estado;
    private Long plantillaId;
    private String fechaCreacion;

    public NotificacionResponse(Notificacion n) {
        this.id = n.getId();
        this.userId = n.getUserId();
        this.destinatario = n.getDestinatario();
        this.canal = n.getCanal();
        this.cuerpoFinal = n.getCuerpoFinal();
        this.estado = n.getEstado();
        this.plantillaId = n.getPlantilla().getId();
        this.fechaCreacion = n.getFechaCreacion().toString();
    }

    public Long getId() { return id; }
    public Long getUserId() { return userId; }
    public String getDestinatario() { return destinatario; }
    public Canal getCanal() { return canal; }
    public String getCuerpoFinal() { return cuerpoFinal; }
    public EstadoNotificacion getEstado() { return estado; }
    public Long getPlantillaId() { return plantillaId; }
    public String getFechaCreacion() { return fechaCreacion; }
}