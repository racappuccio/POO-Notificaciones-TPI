package com.example.TPI_POO_NOTIFICACIONES.Request;

import jakarta.validation.constraints.NotBlank;

public class PlantillaRequest {

    @NotBlank
    private String canal;    // "EMAIL" o "IN_APP"

    @NotBlank
    private String asunto;

    @NotBlank
    private String cuerpo;

    // Getters y setters
    public String getCanal() { return canal; }
    public void setCanal(String canal) { this.canal = canal; }

    public String getAsunto() { return asunto; }
    public void setAsunto(String asunto) { this.asunto = asunto; }

    public String getCuerpo() { return cuerpo; }
    public void setCuerpo(String cuerpo) { this.cuerpo = cuerpo; }
}