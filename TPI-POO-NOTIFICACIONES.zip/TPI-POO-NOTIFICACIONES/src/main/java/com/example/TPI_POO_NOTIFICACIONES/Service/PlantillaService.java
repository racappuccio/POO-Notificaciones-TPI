package com.example.TPI_POO_NOTIFICACIONES.Service;

import com.example.TPI_POO_NOTIFICACIONES.Entity.Canal;
import com.example.TPI_POO_NOTIFICACIONES.Entity.Plantilla;
import com.example.TPI_POO_NOTIFICACIONES.Repository.PlantillaRepository;
import com.example.TPI_POO_NOTIFICACIONES.Request.PlantillaRequest;
import org.springframework.stereotype.Service;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class PlantillaService {

    private final PlantillaRepository plantillaRepository;

    public PlantillaService(PlantillaRepository plantillaRepository) {
        this.plantillaRepository = plantillaRepository;
    }

    @Transactional
    public Plantilla crearPlantilla(PlantillaRequest dto) {
        Plantilla plantilla = new Plantilla(
                dto.getId(),
                Canal.valueOf(dto.getCanal()),
                dto.getAsunto(),
                dto.getCuerpo()
        );
        return plantillaRepository.save(plantilla);
    }

    @Transactional
    public Plantilla actualizarPlantilla(String id, PlantillaRequest dto) {
        Plantilla plantilla = plantillaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Plantilla no encontrada"));

        plantilla.setCanal(Canal.valueOf(dto.getCanal()));
        plantilla.setAsunto(dto.getAsunto());
        plantilla.setCuerpo(dto.getCuerpo());

        return plantillaRepository.save(plantilla);
    }

    public Plantilla obtenerPorId(String id) {
        return plantillaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Plantilla no encontrada"));
    }

    public List<Plantilla> obtenerTodas() {
        return plantillaRepository.findAll();
    }
}