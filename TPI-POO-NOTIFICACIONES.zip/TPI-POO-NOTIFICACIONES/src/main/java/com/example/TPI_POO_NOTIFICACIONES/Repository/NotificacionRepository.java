package com.example.TPI_POO_NOTIFICACIONES.Repository;
import com.example.TPI_POO_NOTIFICACIONES.Entity.EstadoNotificacion;
import com.example.TPI_POO_NOTIFICACIONES.Entity.Notificacion;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface NotificacionRepository extends JpaRepository<Notificacion, String> {
    // Buscar notificaciones por usuario
    List<Notificacion> findByUserId(String userId);

    // Buscar notificaciones por estado
    List<Notificacion> findByEstado(EstadoNotificacion estado);
}