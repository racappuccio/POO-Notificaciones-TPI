package com.example.TPI_POO_NOTIFICACIONES.Controller;

import com.example.TPI_POO_NOTIFICACIONES.Entity.Notificacion;
import com.example.TPI_POO_NOTIFICACIONES.Request.NotificacionRequest;
import com.example.TPI_POO_NOTIFICACIONES.Response.NotificacionResponse;
import com.example.TPI_POO_NOTIFICACIONES.Service.NotificacionService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/notificacion")
public class NotificacionController {

    private final NotificacionService notificacionService;

    public NotificacionController(NotificacionService notificacionService) {
        this.notificacionService = notificacionService;
    }

    // 🔹 Crear una nueva notificación
    @PostMapping
    public ResponseEntity<NotificacionResponse> crear(@RequestBody NotificacionRequest request) {
        Notificacion notificacion = notificacionService.crearNotificacion(request);
        return ResponseEntity.ok(new NotificacionResponse(notificacion));
    }

    // 🔹 Obtener todas las notificaciones
    @GetMapping
    public ResponseEntity<List<NotificacionResponse>> obtenerTodas() {
        List<Notificacion> notificaciones = notificacionService.obtenerTodas();
        List<NotificacionResponse> response = notificaciones.stream()
                .map(NotificacionResponse::new)
                .toList();
        return ResponseEntity.ok(response);
    }

    // 🔹 Obtener notificaciones por usuario
    @GetMapping("/{userId}")
    public ResponseEntity<List<NotificacionResponse>> obtenerPorUsuario(@PathVariable Long userId) {
        List<Notificacion> notificaciones = notificacionService.obtenerPorUsuario(userId);
        List<NotificacionResponse> response = notificaciones.stream()
                .map(NotificacionResponse::new)
                .toList();
        return ResponseEntity.ok(response);
    }

    // 🔹 Eliminar notificación por id
    @DeleteMapping("/id/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        notificacionService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}