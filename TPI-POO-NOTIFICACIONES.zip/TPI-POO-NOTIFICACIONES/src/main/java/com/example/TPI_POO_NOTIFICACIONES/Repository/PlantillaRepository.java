package com.example.TPI_POO_NOTIFICACIONES.Repository;

import com.example.TPI_POO_NOTIFICACIONES.Entity.Plantilla;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlantillaRepository extends JpaRepository<Plantilla, Long> {
}
