package com.example.TPI_POO_NOTIFICACIONES.Service;

import com.example.TPI_POO_NOTIFICACIONES.Entity.Canal;
import com.example.TPI_POO_NOTIFICACIONES.Entity.Notificacion;
import com.example.TPI_POO_NOTIFICACIONES.Entity.Plantilla;
import com.example.TPI_POO_NOTIFICACIONES.Repository.NotificacionRepository;
import com.example.TPI_POO_NOTIFICACIONES.Repository.PlantillaRepository;
import com.example.TPI_POO_NOTIFICACIONES.Request.NotificacionRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class NotificacionService {

    private final NotificacionRepository notificacionRepository;
    private final PlantillaRepository plantillaRepository;

    public NotificacionService(NotificacionRepository notificacionRepository,
                               PlantillaRepository plantillaRepository) {
        this.notificacionRepository = notificacionRepository;
        this.plantillaRepository = plantillaRepository;
    }

    @Transactional
    public Notificacion crearNotificacion(NotificacionRequest dto) {
        Plantilla plantilla = plantillaRepository.findById(dto.getTemplateId())
                .orElseThrow(() -> new RuntimeException("Plantilla no encontrada"));

        String cuerpoFinal = plantilla.render(dto.getVars());

        Notificacion notificacion = new Notificacion(
                dto.getUserId(),
                dto.getTo(),
                Canal.valueOf(dto.getCanal()),
                plantilla
        );
        notificacion.setCuerpoFinal(cuerpoFinal);
        notificacion.marcarEnCola();

        return notificacionRepository.save(notificacion);
    }

    public List<Notificacion> obtenerPorUsuario(String userId) {
        return notificacionRepository.findByUserId(userId);
    }
}