package com.example.TPI_POO_NOTIFICACIONES.Entity;

import jakarta.persistence.*;
import java.util.Map;

@Entity
public class Plantilla {

    @Id
    private Long id;

    @Enumerated(EnumType.STRING)
    private Canal canal;

    private String asunto;

    @Column(length = 2000)
    private String cuerpo;

    // Constructores
    public Plantilla(String id, Canal canal, String asunto, String cuerpo) {}

    public Plantilla(Long id, Canal canal, String asunto, String cuerpo) {
        this.id = id;
        this.canal = canal;
        this.asunto = asunto;
        this.cuerpo = cuerpo;
    }

    // 👉 Aquí va el método render
    public String render(Map<String, String> vars) {
        if (vars == null) return cuerpo;
        String result = cuerpo;
        for (var entry : vars.entrySet()) {
            result = result.replace("{{" + entry.getKey() + "}}", entry.getValue());
        }
        return result;
    }

    // Getters y setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Canal getCanal() { return canal; }
    public void setCanal(Canal canal) { this.canal = canal; }

    public String getAsunto() { return asunto; }
    public void setAsunto(String asunto) { this.asunto = asunto; }

    public String getCuerpo() { return cuerpo; }
    public void setCuerpo(String cuerpo) { this.cuerpo = cuerpo; }
}