package com.example.TPI_POO_NOTIFICACIONES.Request;

import java.util.Map;

public class NotificacionRequest {
    private String canal;       // "EMAIL" o "IN_APP"
    private Long userId;        // ID del usuario destinatario
    private String to;          // dirección de correo o identificador interno
    private Long plantillaId;   // 🔹 corregido: coincide con la entidad y el service
    private Map<String, String> vars; // variables dinámicas para renderizar el cuerpo

    // Getters y setters
    public String getCanal() { return canal; }
    public void setCanal(String canal) { this.canal = canal; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getTo() { return to; }
    public void setTo(String to) { this.to = to; }

    public Long getPlantillaId() { return plantillaId; }
    public void setPlantillaId(Long plantillaId) { this.plantillaId = plantillaId; }

    public Map<String, String> getVars() { return vars; }
    public void setVars(Map<String, String> vars) { this.vars = vars; }
}