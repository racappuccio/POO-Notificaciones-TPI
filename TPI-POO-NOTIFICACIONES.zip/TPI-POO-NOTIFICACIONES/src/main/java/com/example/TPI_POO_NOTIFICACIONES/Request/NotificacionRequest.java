package com.example.TPI_POO_NOTIFICACIONES.Request;

import java.util.Map;

public class NotificacionRequest {
    private String canal;       // "EMAIL" o "IN_APP"
    private String userId;      // ID del usuario destinatario
    private String to;          // dirección de correo o identificador interno
    private String templateId;  // ID de la plantilla a usar
    private Map<String, String> vars; // variables dinámicas para renderizar el cuerpo

    // Getters y setters
    public String getCanal() { return canal; }
    public void setCanal(String canal) { this.canal = canal; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getTo() { return to; }
    public void setTo(String to) { this.to = to; }

    public String getTemplateId() { return templateId; }
    public void setTemplateId(String templateId) { this.templateId = templateId; }

    public Map<String, String> getVars() { return vars; }
    public void setVars(Map<String, String> vars) { this.vars = vars; }
}