package com.example.TPI_POO_NOTIFICACIONES.Controller;

import com.example.TPI_POO_NOTIFICACIONES.Entity.Plantilla;
import com.example.TPI_POO_NOTIFICACIONES.Request.PlantillaRequest;
import com.example.TPI_POO_NOTIFICACIONES.Response.PlantillaResponse;
import com.example.TPI_POO_NOTIFICACIONES.Service.PlantillaService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/plantillas")
public class PlantillaController {

    private final PlantillaService plantillaService;

    public PlantillaController(PlantillaService plantillaService) {
        this.plantillaService = plantillaService;
    }

    // Crear una nueva plantilla
    @PostMapping
    public ResponseEntity<PlantillaResponse> crear(@RequestBody PlantillaRequest request) {
        Plantilla plantilla = plantillaService.crearPlantilla(request);
        return ResponseEntity.ok(new PlantillaResponse(plantilla));
    }

    // Actualizar una plantilla existente
    @PatchMapping("/{id}")
    public ResponseEntity<PlantillaResponse> actualizar(@PathVariable String id,
                                                        @RequestBody PlantillaRequest request) {
        Plantilla plantilla = plantillaService.actualizarPlantilla(id, request);
        return ResponseEntity.ok(new PlantillaResponse(plantilla));
    }

    // Obtener una plantilla por ID
    @GetMapping("/{id}")
    public ResponseEntity<PlantillaResponse> obtenerPorId(@PathVariable String id) {
        Plantilla plantilla = plantillaService.obtenerPorId(id);
        return ResponseEntity.ok(new PlantillaResponse(plantilla));
    }

    // Listar todas las plantillas
    @GetMapping
    public ResponseEntity<List<PlantillaResponse>> obtenerTodas() {
        List<Plantilla> plantillas = plantillaService.obtenerTodas();
        List<PlantillaResponse> response = plantillas.stream()
                .map(PlantillaResponse::new)
                .toList();
        return ResponseEntity.ok(response);
    }
}