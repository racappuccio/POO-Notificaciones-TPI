TPI-POO-NOTIFICACIONES

gestión de notificaciones con Spring Boot y MySQL

Requerimientos de software utilizados:

- Lenguaje: Java 17
- Framework: Spring Boot
- Gestor de dependencias: Maven
- Base de datos: MySQL 8.x
- Librerías principales: Spring Boot Starter Web,Spring Boot Starter Data JPA,Spring Boot Starter Validation,
  Hibernate Core,Spring Boot devtools,MySQL Connector.

Configuración de la base de datos:

CREATE DATABASE notificaciones_db;
CREATE USER 'noti_user'@'localhost' IDENTIFIED BY 'notifrdas18';
GRANT ALL PRIVILEGES ON notificaciones_db.* TO 'noti_user'@'localhost';
FLUSH PRIVILEGES;

Ejemplos de uso:

EJEMPLOS PARA PLANTILLAS:

1-POST /plantillas --> Crear una plantilla 

Request
{
  "canal": "EMAIL",
  "asunto": "Confirmación de compra",
  "cuerpo": "Hola {{nombre}}, gracias por tu compra. Tu pedido #{{pedidoId}} está en proceso."
}

Response 
{
  "id": 1,
  "canal": "EMAIL",
  "asunto": "Confirmación de compra",
  "cuerpo": "Hola {{nombre}}, gracias por tu compra en nuestro Marketplace. Tu pedido #{{pedidoId}} está en proceso."
} 

2-GET /plantillas/{id} --> Obtener una plantilla por id 

Request
GET /plantillas/1

{
  "id": 1,
  "canal": "EMAIL",
  "asunto": "Confirmación de compra",
  "cuerpo": "Hola {{nombre}}, gracias por tu compra. Tu pedido #{{pedidoId}} está en proceso."
}
3-PATCH /plantillas/{id} → Actualizar parcialmente una plantilla
Request:

{
  "asunto": "Confirmación de compra actualizada"
}

Response:

{
  "id": 1,
  "canal": "EMAIL",
  "asunto": "Confirmación de compra actualizada",
  "cuerpo": "Hola {{nombre}}, gracias por tu compra. Tu pedido #{{pedidoId}} está en proceso."

}
4-DELETE /plantillas/{id} --> Eliminar una plantilla 
Request 

DELETE /plantillas/1

Response
{
  "message": "Plantilla con id 1 eliminada correctamente."
}

EJEMPLOS PARA NOTIFICACIONES:

1-POST /notificaciones → Crear una notificación basada en una plantilla
Request:

{
  "destinatario": "cliente@example.com",
  "plantillaId": 1,
  "variables": {
    "nombre": "Rocio",
    "pedidoId": "A12345"
  }
}

Response

{
  "id": 10,
  "destinatario": "cliente@example.com",
  "cuerpoFinal": "Hola Rocio, gracias por tu compra. Tu pedido #A12345 está en proceso.",
  "estado": "ENVIADA",
  "fechaCreacion": "2025-11-30T18:40:00",
  "plantillaId": 1
}

2-GET /notificaciones/{id} --> Obtener una notificacion por id 

Request

GET /notificaciones/10

Response

{
  "id": 10,
  "destinatario": "cliente@example.com",
  "cuerpoFinal": "Hola Rocio, gracias por tu compra. Tu pedido #A12345 está en proceso.",
  "estado": "ENVIADA",
  "fechaCreacion": "2025-11-30T18:40:00",
  "plantillaId": 1
}

3-PATCH /notificaciones{id} --> Actualizar estado de una notificación

Request

{
  "estado": "ENTREGADA"
}

Response

{
  "id": 10,
  "destinatario": "cliente@example.com",
  "cuerpoFinal": "Hola Rocio, gracias por tu compra. Tu pedido #A12345 está en proceso.",
  "estado": "EN_COLA",
  "fechaCreacion": "2025-11-30T18:40:00",
  "plantillaId": 1
}

4-DELETE /notificaciones/{id} --> Eliminar una notificacion

Request 

DELETE /notificaciones/10

Request

{
  "message": "Notificación con id 10 eliminada correctamente."
}
