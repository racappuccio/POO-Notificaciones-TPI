package com.example.TPI_POO_NOTIFICACIONES.Controller;

import com.example.TPI_POO_NOTIFICACIONES.Entity.EstadoNotificacion;
import com.example.TPI_POO_NOTIFICACIONES.Entity.Notificacion;
import com.example.TPI_POO_NOTIFICACIONES.Request.NotificacionRequest;
import com.example.TPI_POO_NOTIFICACIONES.Service.NotificacionService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/notificacion")
public class NotificacionController {

    private final NotificacionService notificacionService;

    public NotificacionController(NotificacionService notificacionService) {
        this.notificacionService = notificacionService;
    }

    @PostMapping
    public ResponseEntity<Notificacion> crear(@RequestBody NotificacionRequest request) {
        Notificacion notificacion = notificacionService.crearNotificacion(request);
        return ResponseEntity.ok(notificacion);
    }

    @GetMapping
    public List<Notificacion> obtenerTodas() {
        return notificacionService.obtenerTodas();
    }

    @GetMapping("/usuario/{userId}")
    public List<Notificacion> obtenerPorUsuario(@PathVariable Long userId) {
        return notificacionService.obtenerPorUsuario(userId);
    }

    @DeleteMapping("/id/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        notificacionService.eliminar(id);
        return ResponseEntity.noContent().build();
    }

    // ✅ Ahora recibe un objeto con campo "estado"
    public static class EstadoWrapper {
        private EstadoNotificacion estado;
        public EstadoNotificacion getEstado() { return estado; }
        public void setEstado(EstadoNotificacion estado) { this.estado = estado; }
    }

    @PatchMapping("/id/{id}")
    public ResponseEntity<Notificacion> actualizarEstado(
            @PathVariable Long id,
            @RequestBody EstadoWrapper request) {
        Notificacion actualizada = notificacionService.actualizarParcial(id, request.getEstado());
        return ResponseEntity.ok(actualizada);
    }
}