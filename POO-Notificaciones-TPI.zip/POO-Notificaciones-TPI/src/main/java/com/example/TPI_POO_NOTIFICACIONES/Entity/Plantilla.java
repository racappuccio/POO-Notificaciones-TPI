package com.example.TPI_POO_NOTIFICACIONES.Entity;

import jakarta.persistence.*;
import java.util.Map;

@Entity
@Table(name = "plantilla")
public class Plantilla {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Hibernate genera AUTO_INCREMENT
    private Long id;

    @Enumerated(EnumType.STRING)
    private Canal canal;

    private String asunto;

    @Column(length = 2000)
    private String cuerpo;

    public Plantilla() {}

    public Plantilla(Canal canal, String asunto, String cuerpo) {
        this.canal = canal;
        this.asunto = asunto;
        this.cuerpo = cuerpo;
    }

    // Getters y Setters
    public Long getId() { return id; }
    public Canal getCanal() { return canal; }
    public String getAsunto() { return asunto; }
    public String getCuerpo() { return cuerpo; }

    public void setId(Long id) { this.id = id; }
    public void setCanal(Canal canal) { this.canal = canal; }
    public void setAsunto(String asunto) { this.asunto = asunto; }
    public void setCuerpo(String cuerpo) { this.cuerpo = cuerpo; }
}
