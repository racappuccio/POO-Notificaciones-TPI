package com.example.TPI_POO_NOTIFICACIONES.Entity;

public enum Canal {
    EMAIL, IN_APP
}

